﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab06_SS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Shane Soderstrom\nCS 1400\nLab 06");
        }

      /*
      
This program converts inputed inches(the circumfrance of 
a wagon wheel) and tells you the number of rotations their 
are in a mile.

Declaire constants. Their are 63360 inches in a MILE, PIE is equal to 3.14.
Receives DIAMETER from user throu Input textbox and stores as a double.
Multiply DIAMETER and PIE and store as a double under CIRCUMFERENCE.
Divide Mile by CIRCUMFERENCE and store as a double under RESULT.
Read out RESULT in textbox called Output.

*/
    }
}
